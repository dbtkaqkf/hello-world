package TalkTalkTalk;

import java.util.*;

public class TalkDTO {

	
	private String nick;
	
	public TalkDTO() {
		
		
		
	}
	
	
	
	public TalkDTO(String nick) {
		this.nick = nick;
		
	}
	
	public String getNick() {
		return nick;
	}
	
}
