package TalkTalkTalk;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

class ServerGUI extends JFrame implements ActionListener{

	ArrayList<ThreadServerClass> threadList = new ArrayList<ThreadServerClass>();

	
	DataOutputStream outputStream;
	Vector user_list1;
   
   private JPanel contentPane;
	private JTextField textField;
	private JButton btn_start;
	private JButton btn_end;
	static int pn;
	ServerSocket ss1;
	Socket s1;
	public void ServerClass(int pn) throws IOException {// 생성자
		// public ServerClass() throws IOException {

		// ServerSocket ss1 = new ServerSsocket(6788);
		ss1 = new ServerSocket(pn);
		System.out.println("서버가동.......");/////////////////

		while (true) {
			this.s1 = ss1.accept();
			System.out.println("접속주소: " + s1.getInetAddress() + " , 접속포트: " + s1.getPort());
			ThreadServerClass tServer1 = new ThreadServerClass(s1);
			// user_list1.add(s1.get)
			tServer1.start();////////
			// 한명이 접속하면 ThreadServerClass 쓰레드에 올려놓음
             
			threadList.add(tServer1);// 컬렉션에 add
			System.out.println("접속자 수 : " + threadList.size());

		} // whle-end

	}

	// 접속중인 쓰레드에게 chat 내용 보냄
	public void sendChat(String chat1) throws IOException {
		for (int i = 0; i < threadList.size(); i++)
			threadList.get(i).outputStream.writeUTF(chat1);

		// 처음에 nickname이 채팅관련 모든 사람에게 전송

	}// sendChat-end
	
	public void ServerFile(String filepath) throws IOException{
		
		File file1 = new File(filepath);
        FileInputStream fis1 = new FileInputStream(file1);
        DataInputStream dis1 = new DataInputStream(fis1);

        DataOutputStream dos1 = new DataOutputStream(s1.getOutputStream());
     


        byte[] byteBae = new byte[(int)file1.length()];

        dos1.writeInt(byteBae.length);
        dos1.write(byteBae);//파일자체를 바이트 배열 전송
        
        
 
	}
	
	
	
	

	public void Earchat(String chat1) throws IOException {

		for (int i = 0; i < threadList.size(); i++)
			threadList.get(i).outputStream.writeUTF(chat1 + "fuck you");
	}
	/*
	 * public void Sendlist(Vector user_list1) throws IOException{ for (int i = 0; i
	 * < threadList.size(); i++)
	 * threadList.get(i).outputStream.writeUTF(user_list1);
	 * 
	 * }
	 */

	class ThreadServerClass extends Thread {// 한명 접속마다 처리할 쓰레드 클래스
		Socket socket1;
		DataInputStream inputStream;
		DataOutputStream outputStream;

		public ThreadServerClass(Socket s1) throws IOException {
			socket1 = s1;
			inputStream = new DataInputStream(s1.getInputStream());

			outputStream = new DataOutputStream(s1.getOutputStream());

		}

		@Override
		public void run() { // remember !!!!!! 한사람 서버로 접속한 경우임
			String nickname = "";
			try {
				if (inputStream != null) {
					nickname = inputStream.readUTF();// 초록왕자 , 은빛공주
			
					sendChat(nickname + " 님 입장~~~~~ (^^) (^^) (^^) ");

				}
				while (inputStream != null) {
					// System.out.println(inputStream.readUTF());
					String chat1 = null;
					chat1 = inputStream.readUTF();

					if (chat1.contains("-->/w")) {
						Earchat(chat1);

					} else {
						sendChat(chat1); // 방가방가 ~~~~

					}

					// 클라이언트가 보낸 채팅 내용을 접속한 모두에게 보냄
				} // 정상채팅의 경우는 계속 while 문안0 에서 반복 loop
			} catch (IOException e) { // 여기로 왔단 얘기는 에러가 발생한 것 //나가버린 경우
				// e.printStackTrace();

			} finally {
				// 나간 쓰레드의 인덱스 찾기
				for (int i = 0; i < threadList.size(); i++) {
					if (socket1.equals(threadList.get(i).socket1)) {// 이 소켓이 누구거???????
						threadList.remove(i);// 찾았다 홍길동 소켓 - 삭제하자는
						try {
							sendChat(nickname + " 님 퇴장~~~~~  (ㅠ.ㅠ) (ㅠ.ㅠ) (ㅠ.ㅠ) ");

						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				System.out.println("접속자 수 : " + threadList.size() + " 명");

			} // finally-end

		}// run-end
	}// ThreadServerClass-end

	

	public ServerGUI() throws IOException {// 생성자

		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 387, 236);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("포트번호");
		lblNewLabel.setBounds(50, 25, 62, 37);
		contentPane.add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(126, 28, 184, 31);
		textField.setColumns(10);
		contentPane.add(textField);

		btn_start = new JButton("서버실행");
		btn_start.setBounds(50, 80, 260, 37);
		btn_start.addActionListener(this);
		contentPane.add(btn_start);

		btn_end = new JButton("서버종료");
		btn_end.setBounds(50, 120, 260, 37);
		btn_end.addActionListener(this);
		contentPane.add(btn_end);
 
		 this.setVisible(true);
	
	}

	// 접속중인 쓰레드에게 chat 내용 보냄

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btn_start) {
			try {
				pn = Integer.parseInt(textField.getText());
				 ServerClass(pn);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} else if (e.getSource() == btn_end) {
			try {
				ss1.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
	public static void main(String args[]) throws IOException {
		new ServerGUI();
		// new ServerClass();////////////
		//new ServerClass(pn);////////////
		
		
	}
}// ServerClass-end

// TcpMulServer.java

