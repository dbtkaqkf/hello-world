package TalkTalkTalk;

import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TcpMulClient extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	Vector user_list1 = new Vector();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TcpMulClient frame = new TcpMulClient();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TcpMulClient() throws ClassNotFoundException, SQLException {

		TalkDAO tDAO = new TalkDAO();
		
		

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 582, 487);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		textField = new JTextField();
		textField.setBounds(52, 117, 166, 27);
		contentPane.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(52, 207, 166, 27);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setBounds(52, 311, 166, 27);
		contentPane.add(textField_2);
		textField_2.setColumns(10);

		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(323, 206, 129, 29);
		contentPane.add(btnNewButton);

		JLabel iplabel1 = new JLabel("ip");
		iplabel1.setBounds(88, 81, 82, 21);
		contentPane.add(iplabel1);

		JLabel iplabel2 = new JLabel("port no");
		iplabel2.setBounds(88, 171, 82, 21);
		contentPane.add(iplabel2);

		JLabel iplabel3 = new JLabel("nickname");
		iplabel3.setBounds(88, 275, 82, 21);
		contentPane.add(iplabel3);

		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				String ip = textField.getText();
				int port = Integer.parseInt(textField_1.getText());
				String nick = textField_2.getText();
				try { // ip 주소 //포트번호
					Socket s1 = new Socket(ip, port);
					System.out.println("서버에 연결....");// connect

					TalkDTO tDTO = new TalkDTO(nick);
					
					DataOutputStream outputStream = new DataOutputStream(s1.getOutputStream());
					DataInputStream inputStream = new DataInputStream(s1.getInputStream());
					outputStream.writeUTF("##" + nick);

					user_list1.add(nick);
					new TalkChatGUI(outputStream, inputStream, nick, user_list1) {
						// io 스트림 및 닉네임을 인자로 전달
						public void closeWork() throws IOException {
							outputStream.close();
							inputStream.close();
							System.exit(0);
						}
					};

					boolean b1 = tDAO.insert_nick(nick);
					if (b1) {
						System.out.println("성공");
					} else {
						 JOptionPane.showConfirmDialog(null, "닉네임 중복");
					}
				} catch (Exception e) {
					// e.printStackTrace(); //주석을 달아야 에러시 화면 매끄럽게 진행,
				}
			}
		});
	}
}
