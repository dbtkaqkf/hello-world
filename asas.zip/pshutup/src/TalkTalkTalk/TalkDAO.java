package TalkTalkTalk;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TalkDAO {

	private Connection con;
	PreparedStatement ps1 = null;
	ResultSet rs1 = null;

	public TalkDAO() throws ClassNotFoundException, SQLException {
		con = new TalkDBconn().getCon();

	}

	public void pslClose() throws SQLException {
		if (ps1 != null)
			ps1.close();

	}

	public void getAllinfoClose() throws SQLException {

		if (rs1 != null)
			rs1.close();
		if (ps1 != null)
			ps1.close();
		if (con != null)
			con.close();

	}

	public boolean insert_nick(String nick) {

		String sql = "insert into Talk_table(nick)  values(?)";
		
		try {
			ps1 = con.prepareStatement(sql);
			ps1.setString(1, nick);
	

			ps1.executeUpdate();
		} catch (SQLException e) {
			
			return false;
		}
		return true;

	}

	public ArrayList<TalkDTO> getALLinfo() throws SQLException {

		ArrayList<TalkDTO> tarray1 = new ArrayList<TalkDTO>();
		String sql = "SELECT * FROM Talk_table ORDER BY nick";

		ps1 = con.prepareStatement(sql);
		rs1 = ps1.executeQuery(sql);

		while (rs1.next()) {
			String nick = rs1.getString("nick");

			TalkDTO tDTO = new TalkDTO(nick);
			tarray1.add(tDTO);

		}
		return tarray1;

	}

}
