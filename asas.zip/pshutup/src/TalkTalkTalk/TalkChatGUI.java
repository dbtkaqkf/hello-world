package TalkTalkTalk;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import TalkTalkTalk.ServerGUI;
public class TalkChatGUI extends JFrame implements Runnable, ActionListener {
	
	

	static DataOutputStream outputStream;
	static DataInputStream inputStream;
	static String nick;

	JPanel contentPane = new JPanel();
	JTextField textField = new JTextField();
	JButton btnNewButton = new JButton("나가기");
	JList list = new JList();
	JScrollPane scrollPane = new JScrollPane();
	JTextArea textArea = new JTextArea();
	JButton btnNewButton_1 = new JButton("파일 전송");
	JFileChooser Jchoo = new JFileChooser();
	Vector user_list1;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 * 
	 * @param user_list1
	 * @param user_list12
	 * @param al2
	 */
	public TalkChatGUI(DataOutputStream outputStream, DataInputStream inputStream, String nick, Vector user_list1) {

		this.outputStream = outputStream;
		this.inputStream = inputStream;
		this.nick = nick;
		this.user_list1 = user_list1;

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 435, 750);

		contentPane.setBackground(new Color(204, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		scrollPane.setBounds(12, 122, 395, 523);
		contentPane.add(scrollPane);

		scrollPane.setViewportView(textArea);
		textArea.setBackground(Color.WHITE);
		textArea.setForeground(Color.black);
		textArea.setFont(new Font("굴림", Font.BOLD, 15));

		textArea.setEditable(false);

		textField.setBounds(12, 659, 395, 37);
		contentPane.add(textField);
		textField.setColumns(10);
		textField.addActionListener(this);

		btnNewButton.setBounds(310, 14, 97, 37);
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(this);

		list.setBounds(12, 14, 277, 94);
		contentPane.add(list);

		btnNewButton_1.setBounds(310, 61, 97, 37);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.addActionListener(this);

		setVisible(true);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				dispose();
				System.exit(0);
				setVisible(false);
			}
		});

		Thread th1 = new Thread(this);
		th1.start();

	}

	public void setlist() {
		list.setListData(user_list1);

	}

public void Sendfile() throws IOException{
	
	int ret =  Jchoo.showOpenDialog(null);
	if(ret != JFileChooser.APPROVE_OPTION) {
		JOptionPane.showMessageDialog(null, "파일을 선택하지 않았습니다","경고",JOptionPane.WARNING_MESSAGE);
		return;
	}
	String filepath = Jchoo.getSelectedFile().getPath();
	
   new ServerGUI().ServerFile(filepath);
	
	
}

	public void Recieve() throws IOException {
		int ret =  Jchoo.showOpenDialog(null);
		if(ret != JFileChooser.APPROVE_OPTION) {
			JOptionPane.showMessageDialog(null, "파일을 선택하지 않았습니다","경고",JOptionPane.WARNING_MESSAGE);
			return;
		}
		
		String filepath = Jchoo.getSelectedFile().getPath();
		
		int len1 = inputStream.readInt();// 서버가 보낸 파일 길이 먼저 받아옴
		byte[] byteBae2 = new byte[len1];
		inputStream.readFully(byteBae2);////// 그리고 내용받아 바이트배열로

		// byte 배열 ---> file 로 저장

		FileOutputStream fos1 = new FileOutputStream(filepath);
		fos1.write(byteBae2);//// 받은 바이트배열 --->파일로

		System.out.println("끄읕");

	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == textField) {
			try {
				outputStream.writeUTF(nick + "-->" + textField.getText());

				// nickname 과 client의 chat을 서버로
			} catch (IOException ee) {
				// ee.printStackTrace();
			}
			textField.setText("");// 서버로 보내고 해당 칸을 클리어
		}
		if (e.getSource() == btnNewButton) {

			dispose();
			System.exit(0);
			setVisible(false);

		}

		if (e.getSource() == btnNewButton_1) {
			try {
				Sendfile();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		}

	}

	Toolkit tk1 = Toolkit.getDefaultToolkit();
//chat 올때마다 beep음 울리게 하려고

	public void run() {// for 받는 thread
		try {
			while (true) {

				setlist();

				String strServer1 = inputStream.readUTF();// 서버로 부터
				if (strServer1 == null) {
					textArea.append("\n" + "종료");
					return;
				}
				textArea.append("\n" + strServer1);// 서버에서온것 textarea에 추가

				// ------------이것해야 스크롤바가 생긴후 맨 마지막 내용이 잘 보임 -------
				int kkeut = textArea.getText().length();
				textArea.setCaretPosition(kkeut);// 커서를 맨뒤로
				// jtarea1.setCaretPosition(0) // 커서를 맨 처음에
				tk1.beep();///////////// chat 올 때마다 beep음

				/*
				 * if(textArea.getText().equals(nick)) { user_list1.add(nick);
				 * list.setListData(user_list1); }
				 */
			}
		} catch (Exception eee) {
			textArea.append("\n" + eee);
		}

	}
}
